package com.mygdx.game;

public class Rect {
    float x,y,w,h;
    Rect(float x,float y,float w,float h){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
    void Offset(Point pos){
        this.x += pos.x;
        this.y += pos.y;
    }
    void Offset(float x,float y){
        this.x += x;
        this.y += y;
    }
    boolean Hit(Rect partner){
        if(this.x < partner.x + partner.w &&
           this.x + this.w >= partner.x &&
           this.y < partner.y + partner.h &&
           this.y + this.h >= partner.y){
            return true;
        }
        return false;
    }
}
