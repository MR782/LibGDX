package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.ParticleEffect;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.Timer;

public class ParticleActor extends Actor {
    private ParticleEffect pe;
    private Sound se;
    private Point position;
    ParticleActor(){
        se = Gdx.audio.newSound(Gdx.files.internal("fire.mp3"));
        final long id = se.loop();
        Timer.schedule(new Timer.Task(){
            @Override
            public void run(){
                se.stop(id);
            }
        }, 10.0f);

        position = new Point(100,400);
        pe = new ParticleEffect();
        pe.load(Gdx.files.internal("fire.party"),
                Gdx.files.internal(""));
        pe.getEmitters().first().setPosition(this.position.x ,this.position.y);
        //再生
        pe.start();
        se.play();
    }
    @Override
    public void act(float dt){
        pe.update(Gdx.graphics.getDeltaTime());
        if(pe.isComplete()){
            pe.start();
        }

    }
    @Override
    public void draw(Batch batch, float alpha)
    {
        pe.draw(batch);
    }
}
