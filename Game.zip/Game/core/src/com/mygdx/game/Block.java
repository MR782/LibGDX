package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class Block extends Actor {
    private Rect hitBox;
    private Point pos;
    Sprite sprite;
    Texture texture;
    Block(){
        pos = new Point(600,100);
        hitBox = new Rect(pos.x,pos.y,0,0);
        texture = new Texture(Gdx.files.internal("block.png"));
        sprite = new Sprite(texture);
    }

    @Override
    public void act(float dt)
    {
        this.pos.x -= 5;
    }
    @Override
    public void draw(Batch batch, float alpha)
    {
        batch.draw(texture,this.pos.x,this.pos.y);
    }
}
