package com.mygdx.game;

public class Point {
    public float x,y;
    Point(float x,float y){
        this.x = x;
        this.y = y;
    }
}
