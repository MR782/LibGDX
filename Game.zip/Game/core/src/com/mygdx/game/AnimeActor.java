package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class AnimeActor extends Actor {
    private float time;
    private TextureAtlas textureAtlas;
    private Animation anim;
    private Point position;
    AnimeActor(){
        this.time = 0;
        this.position = new Point(50,100);
        this.textureAtlas = new TextureAtlas(Gdx.files.internal("angelo.atlas"));
        this.anim = new Animation(1/10f,textureAtlas.getRegions());

    }
    @Override
    public  void act(float dt){
        time += Gdx.graphics.getDeltaTime();
    }
    @Override
    public void draw(Batch batch,float alpha){
        batch.draw((TextureRegion)anim.getKeyFrame(time,true),this.position.x,this.position.y);
    }
}
