package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;

public class Opening extends ScreenAdapter {
    SpriteBatch batch;
    Stage stage;
    Music bgm;
    Opening(){
        batch = new SpriteBatch();
        stage = new Stage();
        stage.addActor(new AnimeActor());
        stage.addActor(new ParticleActor());
        stage.addActor(new Block());
        bgm = Gdx.audio.newMusic(Gdx.files.internal("bgm.mp3"));
        bgm.play();
        bgm.isLooping();
    }
    @Override
    public void show(){

    }
    @Override
    public void render(float dt){
        Gdx.gl.glClearColor(0,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        stage.act();
        stage.draw();
        batch.end();
    }
}
